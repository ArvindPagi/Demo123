export const environment = {
  production: false,
  title : "BillingP",
  tagLine : "A Knowledge Hub",
  api_url : "http://localhost:5553/books"
};

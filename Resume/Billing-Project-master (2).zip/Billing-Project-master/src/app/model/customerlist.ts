export class CustomerList{

   waterMeterNo: number;
   name: string;
   customerCode: number;
   address: string;
   phoneNo: number;
   presentMR: number;
   previousMR: number;
    
}